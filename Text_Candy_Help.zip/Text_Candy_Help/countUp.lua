
--Update the Text of counter
countDownName:setText(countNumber)