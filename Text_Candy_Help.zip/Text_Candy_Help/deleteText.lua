 headerName:delete()
 headerName = nil