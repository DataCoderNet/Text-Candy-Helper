counterName:applyAnimation({
	interval		= 1,
	startNow		= true,
	restartOnChange 	= true,
	delay			= 0,
	--duration		= 3000,
	charWise		= true,
	autoRemoveText  	= true,

	frequency 		= 250,
	startAlpha		= 0.75,
	alphaRange		= 0.25,
	xScaleRange		= 0.25,
	yScaleRange		= 0.25,
	rotationRange		= 25,
	xRange			= 10,
	yRange			= 10
  })