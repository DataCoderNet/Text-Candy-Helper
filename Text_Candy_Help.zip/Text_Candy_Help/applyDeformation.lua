counterName:applyDeform({
	type 		= TextCandy.DEFORM_SHAKE,
	angleVariation	= 25,
	scaleVariation	= 0,
	xVariation	= 0,
	yVariation	= 10
  })